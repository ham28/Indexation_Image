# Computer Vision
My experimentations with computer vision (more coming soon!)

Robot Cardboard Controller Demo: https://youtu.be/mKB4yDORnOY
