You need the JavaCV library that can be found here:
https://github.com/bytedeco/javacv
Scroll down until you see "Downloads" (binary)