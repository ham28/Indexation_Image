It is recommend that this is used with my NXT-Project (https://github.com/chromestone/NXT-Project).
(https://www.youtube.com/watch?v=mKB4yDORnOY)

You need the JavaCV library that can be found here:
https://github.com/bytedeco/javacv
Scroll down until you see "Downloads" (binary)